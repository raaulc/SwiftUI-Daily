//
//  ByeView.swift
//  FirstApp
//
//  Created by 1390411 on 29/07/21.
//

import SwiftUI

struct ByeView: View {
    var body: some View {
        Text("Bye Bye, World!")
    }
}

struct ByeView_Previews: PreviewProvider {
    static var previews: some View {
        ByeView()
    }
}
