//
//  FirstAppApp.swift
//  FirstApp
//
//  Created by 1390411 on 29/07/21.
//

import SwiftUI

@main
struct FirstAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
